// Shared JavaScript for both login.html and home.html
function displayUserInfo() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    document.getElementById('displayUsername').innerText = 'Username:'  + username;
    document.getElementById('displayPassword').innerText = 'Password:' + password;

    // Display the user information div
    document.getElementById('userInfo').style.display = 'block';

    // Redirect to home.html after displaying information (for demonstration purposes)
    setTimeout(function() {
        window.location.href = 'home.html';
    }, 2000); // 2000 milliseconds (2 seconds) delay
}
